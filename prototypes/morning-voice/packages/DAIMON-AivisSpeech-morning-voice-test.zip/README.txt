DAIMON AivisSpeech 朝音声 試聴版
生成日: 2026-08-18

男性モデル
  AivisSpeech「阿井田 茂 / Calm」
  AivisHub UUID: 47e53151-a378-46f3-abee-ce13aa07feb1
  Style: Calm（local style ID 1 / Engine speaker ID 1310138977）

女性モデル
  AivisSpeech「まお / おちつき」
  AivisHub UUID: a59cb814-0083-4369-8542-f51a29e72af7
  Style: おちつき（local style ID 3 / Engine speaker ID 888753763）

ライセンス
  両モデル: Aivis Common Model License (ACML) 1.0
  商用利用: 可（禁止事項に該当しない営利利用）
  DAIMON有料販売版での利用: 可（確定済み朝文章の固定音声として使用）
  生成音声のアプリ同梱: 可
  再配布: 生成音声の同梱・配布は可。モデルファイル自体を再配布する場合はACML本文の添付が必要。
  クレジット: 任意。まおのモデル説明では、表記する場合「AivisSpeech: まお」が案内されている。
  主な禁止事項: なりすまし・ディープフェイク、話者の尊厳を傷つける利用、攻撃・差別・嫌がらせ、虚偽情報、虚偽・誇大広告や非倫理的ビジネス、政治・宗教・陰謀論の扇動、犯罪・反社会的利用。

生成設定
  AivisSpeech Engine 1.0.0（CPU・ローカル生成）
  男性 speedScale: 0.92
  女性 speedScale: 0.90
  読み順: main → 0.65秒 → support → 0.80秒 → impact → 1.00秒
  名前レイヤー: 読み上げなし
  入力文章: 基準HEAD e5ba2bbcb3127f364dac86782c0465f0095fbc66 の languagePacks.ja.morning.slides を一文字も変更せず使用
  正規化: EBU R128 loudnorm（I=-18 LUFS、TP=-1.5 dBTP、LRA=7）
  出力: MP3 / mono / 44.1kHz / 96kbps CBR

男性ファイル再生時間
  morning01.mp3  10.60秒
  morning02.mp3  10.35秒
  morning03.mp3  10.91秒
  morning04.mp3  10.46秒
  morning05.mp3  11.11秒
  morning06.mp3  11.19秒
  morning07.mp3   9.68秒
  morning08.mp3  10.71秒
  morning09.mp3  10.74秒
  morning10.mp3  11.47秒
  morning11.mp3  11.23秒
  morning12.mp3   9.46秒
  合計: 127.90秒（2分07.90秒）
  容量: 1,544,987 bytes

女性ファイル再生時間
  morning01.mp3  11.42秒
  morning02.mp3  11.00秒
  morning03.mp3  11.62秒
  morning04.mp3  11.34秒
  morning05.mp3  12.11秒
  morning06.mp3  12.24秒
  morning07.mp3  10.42秒
  morning08.mp3  11.44秒
  morning09.mp3  11.72秒
  morning10.mp3  12.40秒
  morning11.mp3  12.13秒
  morning12.mp3  10.63秒
  合計: 138.48秒（2分18.48秒）
  容量: 1,671,629 bytes

音声24本合計
  再生時間: 266.38秒（4分26.38秒）
  MP3容量: 3,216,616 bytes

備考
  本ZIPは声の採用判断用試聴版です。DAIMON本体への組み込みは行っていません。
